const botao = document.getElementById('botao-tema');
const body = document.body;
const formulario = document.getElementById('form-contato');
const mensagemFormulario = document.getElementById('mensagem-formulario')

// Persistência do tema
const temasalvo = localStorage.getItem('tema');
temaEscuro(temasalvo === 'escuro');

// Função para alternar entre tema claro e escuro
function temaEscuro(tipo) {
  if (tipo == true) {
    body.classList.add('escuro');
    botao.innerHTML = '<i class="fa-solid fa-sun"></i>';
  } else {
    body.classList.remove('escuro');
    botao.innerHTML = '<i class="fa-solid fa-moon"></i>';
  }
}

botao.addEventListener('click', () => {
  const isescuro = body.classList.toggle('escuro');
  temaEscuro(isescuro);
  localStorage.setItem('tema', isescuro ? 'escuro' : 'claro');
});

// Scroll suave para links de navegação
const navLinks = document.querySelectorAll('#menu ul a.link');
navLinks.forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      const headerHeight = document.querySelector('header').offsetHeight;
      const targetPosition = target.offsetTop - headerHeight - 20;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    }
  });
});

formulario.addEventListener('submit', function(evento) {
    evento.preventDefault();

    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const mensagem = document.getElementById('mensagem').value.trim();

    const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (nome === '' || email === '' || mensagem === '') {
        mensagemFormulario.textContent =
            'Por favor, preencha todos os campos.';
        mensagemFormulario.className = 'erro';
        return;
    }

    if (!emailValido.test(email)) {
        mensagemFormulario.textContent =
            'Por favor, informe um e-mail válido.';
        mensagemFormulario.className = 'erro';
        return;
    }

    // Exibe a confirmação
    mensagemFormulario.textContent =
        'Mensagem enviada com sucesso!';
    mensagemFormulario.className = 'sucesso';

    // Desabilita os campos após o envio
    const camposFormulario = formulario.querySelectorAll(
        'input, textarea, button'
    );

    camposFormulario.forEach(function(campo) {
        campo.disabled = true;
    });
});